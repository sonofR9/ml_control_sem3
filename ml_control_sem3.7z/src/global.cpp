#include "global.h"

namespace optimization {
std::mt19937 SharedGenerator::gen{0};
}
